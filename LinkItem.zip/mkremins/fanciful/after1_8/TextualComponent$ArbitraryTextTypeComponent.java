package mkremins.fanciful.after1_8;

import com.google.common.base.Preconditions;
import com.google.gson.stream.JsonWriter;
import java.util.Map;
import mkremins.fanciful.after1_8.TextualComponent;
import mkremins.fanciful.after1_8.TextualComponent$ArbitraryTextTypeComponent$1;
import org.bukkit.configuration.serialization.ConfigurationSerializable;

final class TextualComponent$ArbitraryTextTypeComponent extends TextualComponent implements ConfigurationSerializable {
   private String _key;
   private String _value;

   public TextualComponent$ArbitraryTextTypeComponent(String var1, String var2) {
      this.setKey(var1);
      this.setValue(var2);
   }

   public String getKey() {
      return this._key;
   }

   public void setKey(String var1) {
      Preconditions.checkArgument(var1 != null && !var1.isEmpty(), "The key must be specified.");
      this._key = var1;
   }

   public String getValue() {
      return this._value;
   }

   public void setValue(String var1) {
      Preconditions.checkArgument(var1 != null, "The value must be specified.");
      this._value = var1;
   }

   public TextualComponent clone() {
      return new TextualComponent$ArbitraryTextTypeComponent(this.getKey(), this.getValue());
   }

   public void writeJson(JsonWriter var1) {
      var1.name(this.getKey()).value(this.getValue());
   }

   public Map serialize() {
      return new TextualComponent$ArbitraryTextTypeComponent$1(this);
   }

   public static TextualComponent$ArbitraryTextTypeComponent deserialize(Map var0) {
      return new TextualComponent$ArbitraryTextTypeComponent(var0.get("key").toString(), var0.get("value").toString());
   }

   public String getReadableString() {
      return this.getValue();
   }
}
