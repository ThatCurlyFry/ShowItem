package mkremins.fanciful.after1_8;

import com.google.common.collect.ImmutableMap;
import com.google.gson.stream.JsonWriter;
import java.util.Map;
import mkremins.fanciful.after1_8.TextualComponent$ArbitraryTextTypeComponent;
import mkremins.fanciful.after1_8.TextualComponent$ComplexTextTypeComponent;
import org.bukkit.configuration.serialization.ConfigurationSerialization;

public abstract class TextualComponent implements Cloneable {
   static {
      ConfigurationSerialization.registerClass(TextualComponent$ArbitraryTextTypeComponent.class);
      ConfigurationSerialization.registerClass(TextualComponent$ComplexTextTypeComponent.class);
   }

   public String toString() {
      return this.getReadableString();
   }

   public abstract String getKey();

   public abstract String getReadableString();

   public abstract TextualComponent clone();

   public abstract void writeJson(JsonWriter var1);

   static TextualComponent deserialize(Map var0) {
      return (TextualComponent)(var0.containsKey("key") && var0.size() == 2 && var0.containsKey("value")?TextualComponent$ArbitraryTextTypeComponent.deserialize(var0):(var0.size() >= 2 && var0.containsKey("key") && !var0.containsKey("value")?TextualComponent$ComplexTextTypeComponent.deserialize(var0):null));
   }

   static boolean isTextKey(String var0) {
      return var0.equals("translate") || var0.equals("text") || var0.equals("score") || var0.equals("selector");
   }

   static boolean isTranslatableText(TextualComponent var0) {
      return var0 instanceof TextualComponent$ComplexTextTypeComponent && ((TextualComponent$ComplexTextTypeComponent)var0).getKey().equals("translate");
   }

   public static TextualComponent rawText(String var0) {
      return new TextualComponent$ArbitraryTextTypeComponent("text", var0);
   }

   public static TextualComponent localizedText(String var0) {
      return new TextualComponent$ArbitraryTextTypeComponent("translate", var0);
   }

   private static void throwUnsupportedSnapshot() {
      throw new UnsupportedOperationException("This feature is only supported in snapshot releases.");
   }

   public static TextualComponent objectiveScore(String var0) {
      return objectiveScore("*", var0);
   }

   public static TextualComponent objectiveScore(String var0, String var1) {
      throwUnsupportedSnapshot();
      return new TextualComponent$ComplexTextTypeComponent("score", ImmutableMap.builder().put("name", var0).put("objective", var1).build());
   }

   public static TextualComponent selector(String var0) {
      throwUnsupportedSnapshot();
      return new TextualComponent$ArbitraryTextTypeComponent("selector", var0);
   }
}
