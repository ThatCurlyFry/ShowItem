package mkremins.fanciful.after1_8;

import com.google.gson.stream.JsonWriter;
import java.io.IOException;

interface JsonRepresentedObject {
   void writeJson(JsonWriter var1) throws IOException;
}
