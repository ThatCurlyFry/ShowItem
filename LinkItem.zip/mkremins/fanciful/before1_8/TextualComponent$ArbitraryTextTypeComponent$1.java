package mkremins.fanciful.before1_8;

import java.util.HashMap;
import mkremins.fanciful.before1_8.TextualComponent$ArbitraryTextTypeComponent;

class TextualComponent$ArbitraryTextTypeComponent$1 extends HashMap {
   TextualComponent$ArbitraryTextTypeComponent$1(TextualComponent$ArbitraryTextTypeComponent var1) {
      this.this$1 = var1;
      this.put("key", var1.getKey());
      this.put("value", var1.getValue());
   }
}
