package mkremins.fanciful.before1_8;

import java.io.IOException;
import java.io.StringWriter;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.logging.Level;
import mkremins.fanciful.before1_8.JsonRepresentedObject;
import mkremins.fanciful.before1_8.JsonString;
import mkremins.fanciful.before1_8.MessagePart;
import mkremins.fanciful.before1_8.TextualComponent;
import net.amoebaman.util.ArrayWrapper;
import net.amoebaman.util.Reflection;
import org.bukkit.Achievement;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.Statistic;
import org.bukkit.Statistic.Type;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.serialization.ConfigurationSerializable;
import org.bukkit.configuration.serialization.ConfigurationSerialization;
import org.bukkit.craftbukkit.libs.com.google.gson.JsonArray;
import org.bukkit.craftbukkit.libs.com.google.gson.JsonElement;
import org.bukkit.craftbukkit.libs.com.google.gson.JsonObject;
import org.bukkit.craftbukkit.libs.com.google.gson.JsonParser;
import org.bukkit.craftbukkit.libs.com.google.gson.stream.JsonWriter;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public class FancyMessage implements JsonRepresentedObject, Cloneable, Iterable, ConfigurationSerializable {
   private List messageParts;
   private String jsonString;
   private boolean dirty;
   private static Constructor nmsPacketPlayOutChatConstructor;
   private static Object nmsChatSerializerGsonInstance;
   private static Method fromJsonMethod;
   private static JsonParser _stringParser;

   static {
      ConfigurationSerialization.registerClass(FancyMessage.class);
      _stringParser = new JsonParser();
   }

   public FancyMessage clone() {
      FancyMessage var1 = (FancyMessage)super.clone();
      var1.messageParts = new ArrayList(this.messageParts.size());

      for(int var2 = 0; var2 < this.messageParts.size(); ++var2) {
         var1.messageParts.add(var2, ((MessagePart)this.messageParts.get(var2)).clone());
      }

      var1.dirty = false;
      var1.jsonString = null;
      return var1;
   }

   public FancyMessage(String var1) {
      this(TextualComponent.rawText(var1));
   }

   public FancyMessage(TextualComponent var1) {
      this.messageParts = new ArrayList();
      this.messageParts.add(new MessagePart(var1));
      this.jsonString = null;
      this.dirty = false;
      if(nmsPacketPlayOutChatConstructor == null) {
         try {
            nmsPacketPlayOutChatConstructor = Reflection.getNMSClass("PacketPlayOutChat").getDeclaredConstructor(new Class[]{Reflection.getNMSClass("IChatBaseComponent")});
            nmsPacketPlayOutChatConstructor.setAccessible(true);
         } catch (NoSuchMethodException var3) {
            Bukkit.getLogger().log(Level.SEVERE, "Could not find Minecraft method or constructor.", var3);
         } catch (SecurityException var4) {
            Bukkit.getLogger().log(Level.WARNING, "Could not access constructor.", var4);
         }
      }

   }

   public FancyMessage() {
      this((TextualComponent)null);
   }

   public FancyMessage text(String var1) {
      MessagePart var2 = this.latest();
      var2.text = TextualComponent.rawText(var1);
      this.dirty = true;
      return this;
   }

   public FancyMessage text(TextualComponent var1) {
      MessagePart var2 = this.latest();
      var2.text = var1;
      this.dirty = true;
      return this;
   }

   public FancyMessage color(ChatColor var1) {
      if(!var1.isColor()) {
         throw new IllegalArgumentException(var1.name() + " is not a color");
      } else {
         this.latest().color = var1;
         this.dirty = true;
         return this;
      }
   }

   public FancyMessage style(ChatColor... var1) {
      ChatColor[] var5 = var1;
      int var4 = var1.length;

      for(int var3 = 0; var3 < var4; ++var3) {
         ChatColor var2 = var5[var3];
         if(!var2.isFormat()) {
            throw new IllegalArgumentException(var2.name() + " is not a style");
         }
      }

      this.latest().styles.addAll(Arrays.asList(var1));
      this.dirty = true;
      return this;
   }

   public FancyMessage file(String var1) {
      this.onClick("open_file", var1);
      return this;
   }

   public FancyMessage link(String var1) {
      this.onClick("open_url", var1);
      return this;
   }

   public FancyMessage suggest(String var1) {
      this.onClick("suggest_command", var1);
      return this;
   }

   public FancyMessage insert(String var1) {
      this.latest().insertionData = var1;
      this.dirty = true;
      return this;
   }

   public FancyMessage command(String var1) {
      this.onClick("run_command", var1);
      return this;
   }

   public FancyMessage achievementTooltip(String var1) {
      this.onHover("show_achievement", new JsonString("achievement." + var1));
      return this;
   }

   public FancyMessage achievementTooltip(Achievement var1) {
      FancyMessage var10000;
      try {
         Object var2 = Reflection.getMethod(Reflection.getOBCClass("CraftStatistic"), "getNMSAchievement", new Class[]{Achievement.class}).invoke((Object)null, new Object[]{var1});
         var10000 = this.achievementTooltip((String)Reflection.getField(Reflection.getNMSClass("Achievement"), "name").get(var2));
      } catch (IllegalAccessException var3) {
         Bukkit.getLogger().log(Level.WARNING, "Could not access method.", var3);
         return this;
      } catch (IllegalArgumentException var4) {
         Bukkit.getLogger().log(Level.WARNING, "Argument could not be passed.", var4);
         return this;
      } catch (InvocationTargetException var5) {
         Bukkit.getLogger().log(Level.WARNING, "A error has occured durring invoking of method.", var5);
         return this;
      }

      return var10000;
   }

   public FancyMessage statisticTooltip(Statistic var1) {
      Type var2 = var1.getType();
      if(var2 != Type.UNTYPED) {
         throw new IllegalArgumentException("That statistic requires an additional " + var2 + " parameter!");
      } else {
         FancyMessage var10000;
         try {
            Object var3 = Reflection.getMethod(Reflection.getOBCClass("CraftStatistic"), "getNMSStatistic", new Class[]{Statistic.class}).invoke((Object)null, new Object[]{var1});
            var10000 = this.achievementTooltip((String)Reflection.getField(Reflection.getNMSClass("Statistic"), "name").get(var3));
         } catch (IllegalAccessException var4) {
            Bukkit.getLogger().log(Level.WARNING, "Could not access method.", var4);
            return this;
         } catch (IllegalArgumentException var5) {
            Bukkit.getLogger().log(Level.WARNING, "Argument could not be passed.", var5);
            return this;
         } catch (InvocationTargetException var6) {
            Bukkit.getLogger().log(Level.WARNING, "A error has occured durring invoking of method.", var6);
            return this;
         }

         return var10000;
      }
   }

   public FancyMessage statisticTooltip(Statistic var1, Material var2) {
      Type var3 = var1.getType();
      if(var3 == Type.UNTYPED) {
         throw new IllegalArgumentException("That statistic needs no additional parameter!");
      } else if((var3 != Type.BLOCK || !var2.isBlock()) && var3 != Type.ENTITY) {
         FancyMessage var10000;
         try {
            Object var4 = Reflection.getMethod(Reflection.getOBCClass("CraftStatistic"), "getMaterialStatistic", new Class[]{Statistic.class, Material.class}).invoke((Object)null, new Object[]{var1, var2});
            var10000 = this.achievementTooltip((String)Reflection.getField(Reflection.getNMSClass("Statistic"), "name").get(var4));
         } catch (IllegalAccessException var5) {
            Bukkit.getLogger().log(Level.WARNING, "Could not access method.", var5);
            return this;
         } catch (IllegalArgumentException var6) {
            Bukkit.getLogger().log(Level.WARNING, "Argument could not be passed.", var6);
            return this;
         } catch (InvocationTargetException var7) {
            Bukkit.getLogger().log(Level.WARNING, "A error has occured durring invoking of method.", var7);
            return this;
         }

         return var10000;
      } else {
         throw new IllegalArgumentException("Wrong parameter type for that statistic - needs " + var3 + "!");
      }
   }

   public FancyMessage statisticTooltip(Statistic var1, EntityType var2) {
      Type var3 = var1.getType();
      if(var3 == Type.UNTYPED) {
         throw new IllegalArgumentException("That statistic needs no additional parameter!");
      } else if(var3 != Type.ENTITY) {
         throw new IllegalArgumentException("Wrong parameter type for that statistic - needs " + var3 + "!");
      } else {
         FancyMessage var10000;
         try {
            Object var4 = Reflection.getMethod(Reflection.getOBCClass("CraftStatistic"), "getEntityStatistic", new Class[]{Statistic.class, EntityType.class}).invoke((Object)null, new Object[]{var1, var2});
            var10000 = this.achievementTooltip((String)Reflection.getField(Reflection.getNMSClass("Statistic"), "name").get(var4));
         } catch (IllegalAccessException var5) {
            Bukkit.getLogger().log(Level.WARNING, "Could not access method.", var5);
            return this;
         } catch (IllegalArgumentException var6) {
            Bukkit.getLogger().log(Level.WARNING, "Argument could not be passed.", var6);
            return this;
         } catch (InvocationTargetException var7) {
            Bukkit.getLogger().log(Level.WARNING, "A error has occured durring invoking of method.", var7);
            return this;
         }

         return var10000;
      }
   }

   public FancyMessage itemTooltip(String var1) {
      this.onHover("show_item", new JsonString(var1));
      return this;
   }

   public FancyMessage itemTooltip(ItemStack var1) {
      FancyMessage var10000;
      try {
         Object var2 = Reflection.getMethod(Reflection.getOBCClass("inventory.CraftItemStack"), "asNMSCopy", new Class[]{ItemStack.class}).invoke((Object)null, new Object[]{var1});
         var10000 = this.itemTooltip(Reflection.getMethod(Reflection.getNMSClass("ItemStack"), "save", new Class[]{Reflection.getNMSClass("NBTTagCompound")}).invoke(var2, new Object[]{Reflection.getNMSClass("NBTTagCompound").newInstance()}).toString());
      } catch (Exception var3) {
         var3.printStackTrace();
         return this;
      }

      return var10000;
   }

   public FancyMessage tooltip(String var1) {
      this.onHover("show_text", new JsonString(var1));
      return this;
   }

   public FancyMessage tooltip(Iterable var1) {
      this.tooltip((String[])ArrayWrapper.toArray(var1, String.class));
      return this;
   }

   public FancyMessage tooltip(String... var1) {
      StringBuilder var2 = new StringBuilder();

      for(int var3 = 0; var3 < var1.length; ++var3) {
         var2.append(var1[var3]);
         if(var3 != var1.length - 1) {
            var2.append('\n');
         }
      }

      this.tooltip(var2.toString());
      return this;
   }

   public FancyMessage formattedTooltip(FancyMessage var1) {
      Iterator var3 = var1.messageParts.iterator();

      MessagePart var2;
      do {
         if(!var3.hasNext()) {
            this.onHover("show_text", var1);
            return this;
         }

         var2 = (MessagePart)var3.next();
         if(var2.clickActionData != null && var2.clickActionName != null) {
            throw new IllegalArgumentException("The tooltip text cannot have click data.");
         }
      } while(var2.hoverActionData == null || var2.hoverActionName == null);

      throw new IllegalArgumentException("The tooltip text cannot have a tooltip.");
   }

   public FancyMessage formattedTooltip(FancyMessage... var1) {
      if(var1.length < 1) {
         this.onHover((String)null, (JsonRepresentedObject)null);
         return this;
      } else {
         FancyMessage var2 = new FancyMessage();
         var2.messageParts.clear();

         for(int var3 = 0; var3 < var1.length; ++var3) {
            try {
               Iterator var5 = var1[var3].iterator();

               while(var5.hasNext()) {
                  MessagePart var4 = (MessagePart)var5.next();
                  if(var4.clickActionData != null && var4.clickActionName != null) {
                     throw new IllegalArgumentException("The tooltip text cannot have click data.");
                  }

                  if(var4.hoverActionData != null && var4.hoverActionName != null) {
                     throw new IllegalArgumentException("The tooltip text cannot have a tooltip.");
                  }

                  if(var4.hasText()) {
                     var2.messageParts.add(var4.clone());
                  }
               }

               if(var3 != var1.length - 1) {
                  var2.messageParts.add(new MessagePart(TextualComponent.rawText("\n")));
               }
            } catch (CloneNotSupportedException var6) {
               Bukkit.getLogger().log(Level.WARNING, "Failed to clone object", var6);
               return this;
            }
         }

         return this.formattedTooltip(var2.messageParts.isEmpty()?null:var2);
      }
   }

   public FancyMessage formattedTooltip(Iterable var1) {
      return this.formattedTooltip((FancyMessage[])ArrayWrapper.toArray(var1, FancyMessage.class));
   }

   public FancyMessage translationReplacements(String... var1) {
      String[] var5 = var1;
      int var4 = var1.length;

      for(int var3 = 0; var3 < var4; ++var3) {
         String var2 = var5[var3];
         this.latest().translationReplacements.add(new JsonString(var2));
      }

      this.dirty = true;
      return this;
   }

   public FancyMessage translationReplacements(FancyMessage... var1) {
      FancyMessage[] var5 = var1;
      int var4 = var1.length;

      for(int var3 = 0; var3 < var4; ++var3) {
         FancyMessage var2 = var5[var3];
         this.latest().translationReplacements.add(var2);
      }

      this.dirty = true;
      return this;
   }

   public FancyMessage translationReplacements(Iterable var1) {
      return this.translationReplacements((FancyMessage[])ArrayWrapper.toArray(var1, FancyMessage.class));
   }

   public FancyMessage then(String var1) {
      return this.then(TextualComponent.rawText(var1));
   }

   public FancyMessage then(TextualComponent var1) {
      if(!this.latest().hasText()) {
         throw new IllegalStateException("previous message part has no text");
      } else {
         this.messageParts.add(new MessagePart(var1));
         this.dirty = true;
         return this;
      }
   }

   public FancyMessage then() {
      if(!this.latest().hasText()) {
         throw new IllegalStateException("previous message part has no text");
      } else {
         this.messageParts.add(new MessagePart());
         this.dirty = true;
         return this;
      }
   }

   public void writeJson(JsonWriter var1) {
      if(this.messageParts.size() == 1) {
         this.latest().writeJson(var1);
      } else {
         var1.beginObject().name("text").value("").name("extra").beginArray();
         Iterator var3 = this.iterator();

         while(var3.hasNext()) {
            MessagePart var2 = (MessagePart)var3.next();
            var2.writeJson(var1);
         }

         var1.endArray().endObject();
      }

   }

   public String toJSONString() {
      if(!this.dirty && this.jsonString != null) {
         return this.jsonString;
      } else {
         StringWriter var1 = new StringWriter();
         JsonWriter var2 = new JsonWriter(var1);

         try {
            this.writeJson(var2);
            var2.close();
         } catch (IOException var4) {
            throw new RuntimeException("invalid message");
         }

         this.jsonString = var1.toString();
         this.dirty = false;
         return this.jsonString;
      }
   }

   public void send(Player var1) {
      this.send(var1, this.toJSONString());
   }

   private void send(CommandSender var1, String var2) {
      if(!(var1 instanceof Player)) {
         var1.sendMessage(this.toOldMessageFormat());
      } else {
         Player var3 = (Player)var1;

         try {
            Object var4 = Reflection.getHandle(var3);
            Object var5 = Reflection.getField(var4.getClass(), "playerConnection").get(var4);
            Reflection.getMethod(var5.getClass(), "sendPacket", new Class[]{Reflection.getNMSClass("Packet")}).invoke(var5, new Object[]{this.createChatPacket(var2)});
         } catch (IllegalArgumentException var6) {
            Bukkit.getLogger().log(Level.WARNING, "Argument could not be passed.", var6);
         } catch (IllegalAccessException var7) {
            Bukkit.getLogger().log(Level.WARNING, "Could not access method.", var7);
         } catch (InstantiationException var8) {
            Bukkit.getLogger().log(Level.WARNING, "Underlying class is abstract.", var8);
         } catch (InvocationTargetException var9) {
            Bukkit.getLogger().log(Level.WARNING, "A error has occured durring invoking of method.", var9);
         } catch (NoSuchMethodException var10) {
            Bukkit.getLogger().log(Level.WARNING, "Could not find method.", var10);
         } catch (ClassNotFoundException var11) {
            Bukkit.getLogger().log(Level.WARNING, "Could not find class.", var11);
         }

      }
   }

   private Object createChatPacket(String var1) {
      if(nmsChatSerializerGsonInstance == null) {
         String var3 = Reflection.getVersion();
         double var4 = Double.parseDouble(var3.replace('_', '.').substring(1, 4));
         int var6 = Integer.parseInt(var3.substring(6, 7));
         Class var2;
         if(var4 >= 1.8D && (var4 != 1.8D || var6 != 1)) {
            var2 = Reflection.getNMSClass("IChatBaseComponent$ChatSerializer");
         } else {
            var2 = Reflection.getNMSClass("ChatSerializer");
         }

         if(var2 == null) {
            throw new ClassNotFoundException("Can\'t find the ChatSerializer class");
         }

         Field[] var10;
         int var9 = (var10 = var2.getDeclaredFields()).length;

         for(int var8 = 0; var8 < var9; ++var8) {
            Field var7 = var10[var8];
            if(Modifier.isFinal(var7.getModifiers()) && Modifier.isStatic(var7.getModifiers()) && var7.getType().getName().endsWith("Gson")) {
               var7.setAccessible(true);
               nmsChatSerializerGsonInstance = var7.get((Object)null);
               fromJsonMethod = nmsChatSerializerGsonInstance.getClass().getMethod("fromJson", new Class[]{String.class, Class.class});
               break;
            }
         }
      }

      Object var11 = fromJsonMethod.invoke(nmsChatSerializerGsonInstance, new Object[]{var1, Reflection.getNMSClass("IChatBaseComponent")});
      return nmsPacketPlayOutChatConstructor.newInstance(new Object[]{var11});
   }

   public void send(CommandSender var1) {
      this.send(var1, this.toJSONString());
   }

   public void send(Iterable var1) {
      String var2 = this.toJSONString();
      Iterator var4 = var1.iterator();

      while(var4.hasNext()) {
         CommandSender var3 = (CommandSender)var4.next();
         this.send(var3, var2);
      }

   }

   public String toOldMessageFormat() {
      StringBuilder var1 = new StringBuilder();
      Iterator var3 = this.iterator();

      while(var3.hasNext()) {
         MessagePart var2 = (MessagePart)var3.next();
         var1.append(var2.color == null?"":var2.color);
         Iterator var5 = var2.styles.iterator();

         while(var5.hasNext()) {
            ChatColor var4 = (ChatColor)var5.next();
            var1.append(var4);
         }

         var1.append(var2.text);
      }

      return var1.toString();
   }

   private MessagePart latest() {
      return (MessagePart)this.messageParts.get(this.messageParts.size() - 1);
   }

   private void onClick(String var1, String var2) {
      MessagePart var3 = this.latest();
      var3.clickActionName = var1;
      var3.clickActionData = var2;
      this.dirty = true;
   }

   private void onHover(String var1, JsonRepresentedObject var2) {
      MessagePart var3 = this.latest();
      var3.hoverActionName = var1;
      var3.hoverActionData = var2;
      this.dirty = true;
   }

   public Map serialize() {
      HashMap var1 = new HashMap();
      var1.put("messageParts", this.messageParts);
      return var1;
   }

   public static FancyMessage deserialize(Map var0) {
      FancyMessage var1 = new FancyMessage();
      var1.messageParts = (List)var0.get("messageParts");
      var1.jsonString = var0.containsKey("JSON")?var0.get("JSON").toString():null;
      var1.dirty = !var0.containsKey("JSON");
      return var1;
   }

   public Iterator iterator() {
      return this.messageParts.iterator();
   }

   public static FancyMessage deserialize(String var0) {
      JsonObject var1 = _stringParser.parse(var0).getAsJsonObject();
      JsonArray var2 = var1.getAsJsonArray("extra");
      FancyMessage var3 = new FancyMessage();
      var3.messageParts.clear();

      MessagePart var6;
      label76:
      for(Iterator var5 = var2.iterator(); var5.hasNext(); var3.messageParts.add(var6)) {
         JsonElement var4 = (JsonElement)var5.next();
         var6 = new MessagePart();
         JsonObject var7 = var4.getAsJsonObject();
         Iterator var9 = var7.entrySet().iterator();

         while(true) {
            while(true) {
               if(!var9.hasNext()) {
                  continue label76;
               }

               Entry var8 = (Entry)var9.next();
               if(TextualComponent.isTextKey((String)var8.getKey())) {
                  HashMap var14 = new HashMap();
                  var14.put("key", var8.getKey());
                  if(((JsonElement)var8.getValue()).isJsonPrimitive()) {
                     var14.put("value", ((JsonElement)var8.getValue()).getAsString());
                  } else {
                     Iterator var12 = ((JsonElement)var8.getValue()).getAsJsonObject().entrySet().iterator();

                     while(var12.hasNext()) {
                        Entry var15 = (Entry)var12.next();
                        var14.put("value." + (String)var15.getKey(), ((JsonElement)var15.getValue()).getAsString());
                     }
                  }

                  var6.text = TextualComponent.deserialize(var14);
               } else if(MessagePart.stylesToNames.inverse().containsKey(var8.getKey())) {
                  if(((JsonElement)var8.getValue()).getAsBoolean()) {
                     var6.styles.add((ChatColor)MessagePart.stylesToNames.inverse().get(var8.getKey()));
                  }
               } else if(((String)var8.getKey()).equals("color")) {
                  var6.color = ChatColor.valueOf(((JsonElement)var8.getValue()).getAsString().toUpperCase());
               } else {
                  JsonObject var13;
                  if(((String)var8.getKey()).equals("clickEvent")) {
                     var13 = ((JsonElement)var8.getValue()).getAsJsonObject();
                     var6.clickActionName = var13.get("action").getAsString();
                     var6.clickActionData = var13.get("value").getAsString();
                  } else if(((String)var8.getKey()).equals("hoverEvent")) {
                     var13 = ((JsonElement)var8.getValue()).getAsJsonObject();
                     var6.hoverActionName = var13.get("action").getAsString();
                     if(var13.get("value").isJsonPrimitive()) {
                        var6.hoverActionData = new JsonString(var13.get("value").getAsString());
                     } else {
                        var6.hoverActionData = deserialize(var13.get("value").toString());
                     }
                  } else if(((String)var8.getKey()).equals("insertion")) {
                     var6.insertionData = ((JsonElement)var8.getValue()).getAsString();
                  } else if(((String)var8.getKey()).equals("with")) {
                     Iterator var11 = ((JsonElement)var8.getValue()).getAsJsonArray().iterator();

                     while(var11.hasNext()) {
                        JsonElement var10 = (JsonElement)var11.next();
                        if(var10.isJsonPrimitive()) {
                           var6.translationReplacements.add(new JsonString(var10.getAsString()));
                        } else {
                           var6.translationReplacements.add(deserialize(var10.toString()));
                        }
                     }
                  }
               }
            }
         }
      }

      return var3;
   }
}
