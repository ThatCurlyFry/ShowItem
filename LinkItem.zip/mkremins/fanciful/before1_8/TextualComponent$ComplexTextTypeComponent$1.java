package mkremins.fanciful.before1_8;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import mkremins.fanciful.before1_8.TextualComponent$ComplexTextTypeComponent;

class TextualComponent$ComplexTextTypeComponent$1 extends HashMap {
   TextualComponent$ComplexTextTypeComponent$1(TextualComponent$ComplexTextTypeComponent var1) {
      this.this$1 = var1;
      this.put("key", var1.getKey());
      Iterator var3 = var1.getValue().entrySet().iterator();

      while(var3.hasNext()) {
         Entry var2 = (Entry)var3.next();
         this.put("value." + (String)var2.getKey(), var2.getValue());
      }

   }
}
