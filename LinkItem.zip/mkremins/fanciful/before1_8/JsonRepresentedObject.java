package mkremins.fanciful.before1_8;

import java.io.IOException;
import org.bukkit.craftbukkit.libs.com.google.gson.stream.JsonWriter;

interface JsonRepresentedObject {
   void writeJson(JsonWriter var1) throws IOException;
}
