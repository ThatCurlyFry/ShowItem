package mkremins.fanciful.before1_8;

import com.google.common.collect.BiMap;
import com.google.common.collect.ImmutableBiMap;
import com.google.common.collect.ImmutableBiMap.Builder;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.logging.Level;
import mkremins.fanciful.before1_8.FancyMessage;
import mkremins.fanciful.before1_8.JsonRepresentedObject;
import mkremins.fanciful.before1_8.JsonString;
import mkremins.fanciful.before1_8.TextualComponent;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.configuration.serialization.ConfigurationSerializable;
import org.bukkit.configuration.serialization.ConfigurationSerialization;
import org.bukkit.craftbukkit.libs.com.google.gson.stream.JsonWriter;

final class MessagePart implements JsonRepresentedObject, ConfigurationSerializable, Cloneable {
   ChatColor color;
   ArrayList styles;
   String clickActionName;
   String clickActionData;
   String hoverActionName;
   JsonRepresentedObject hoverActionData;
   TextualComponent text;
   String insertionData;
   ArrayList translationReplacements;
   static final BiMap stylesToNames;

   static {
      Builder var0 = ImmutableBiMap.builder();
      ChatColor[] var4;
      int var3 = (var4 = ChatColor.values()).length;

      for(int var2 = 0; var2 < var3; ++var2) {
         ChatColor var1 = var4[var2];
         if(var1.isFormat()) {
            String var5;
            switch($SWITCH_TABLE$org$bukkit$ChatColor()[var1.ordinal()]) {
            case 17:
               var5 = "obfuscated";
               break;
            case 18:
            case 19:
            default:
               var5 = var1.name().toLowerCase();
               break;
            case 20:
               var5 = "underlined";
            }

            var0.put(var1, var5);
         }
      }

      stylesToNames = var0.build();
      ConfigurationSerialization.registerClass(MessagePart.class);
   }

   MessagePart(TextualComponent var1) {
      this.color = ChatColor.WHITE;
      this.styles = new ArrayList();
      this.clickActionName = null;
      this.clickActionData = null;
      this.hoverActionName = null;
      this.hoverActionData = null;
      this.text = null;
      this.insertionData = null;
      this.translationReplacements = new ArrayList();
      this.text = var1;
   }

   MessagePart() {
      this.color = ChatColor.WHITE;
      this.styles = new ArrayList();
      this.clickActionName = null;
      this.clickActionData = null;
      this.hoverActionName = null;
      this.hoverActionData = null;
      this.text = null;
      this.insertionData = null;
      this.translationReplacements = new ArrayList();
      this.text = null;
   }

   boolean hasText() {
      return this.text != null;
   }

   public MessagePart clone() {
      MessagePart var1 = (MessagePart)super.clone();
      var1.styles = (ArrayList)this.styles.clone();
      if(this.hoverActionData instanceof JsonString) {
         var1.hoverActionData = new JsonString(((JsonString)this.hoverActionData).getValue());
      } else if(this.hoverActionData instanceof FancyMessage) {
         var1.hoverActionData = ((FancyMessage)this.hoverActionData).clone();
      }

      var1.translationReplacements = (ArrayList)this.translationReplacements.clone();
      return var1;
   }

   public void writeJson(JsonWriter var1) {
      try {
         var1.beginObject();
         this.text.writeJson(var1);
         var1.name("color").value(this.color.name().toLowerCase());
         Iterator var3 = this.styles.iterator();

         while(var3.hasNext()) {
            ChatColor var2 = (ChatColor)var3.next();
            var1.name((String)stylesToNames.get(var2)).value(true);
         }

         if(this.clickActionName != null && this.clickActionData != null) {
            var1.name("clickEvent").beginObject().name("action").value(this.clickActionName).name("value").value(this.clickActionData).endObject();
         }

         if(this.hoverActionName != null && this.hoverActionData != null) {
            var1.name("hoverEvent").beginObject().name("action").value(this.hoverActionName).name("value");
            this.hoverActionData.writeJson(var1);
            var1.endObject();
         }

         if(this.insertionData != null) {
            var1.name("insertion").value(this.insertionData);
         }

         if(this.translationReplacements.size() > 0 && this.text != null && TextualComponent.isTranslatableText(this.text)) {
            var1.name("with").beginArray();
            var3 = this.translationReplacements.iterator();

            while(var3.hasNext()) {
               JsonRepresentedObject var5 = (JsonRepresentedObject)var3.next();
               var5.writeJson(var1);
            }

            var1.endArray();
         }

         var1.endObject();
      } catch (IOException var4) {
         Bukkit.getLogger().log(Level.WARNING, "A problem occured during writing of JSON string", var4);
      }

   }

   public Map serialize() {
      HashMap var1 = new HashMap();
      var1.put("text", this.text);
      var1.put("styles", this.styles);
      var1.put("color", Character.valueOf(this.color.getChar()));
      var1.put("hoverActionName", this.hoverActionName);
      var1.put("hoverActionData", this.hoverActionData);
      var1.put("clickActionName", this.clickActionName);
      var1.put("clickActionData", this.clickActionData);
      var1.put("insertion", this.insertionData);
      var1.put("translationReplacements", this.translationReplacements);
      return var1;
   }

   public static MessagePart deserialize(Map var0) {
      MessagePart var1 = new MessagePart((TextualComponent)var0.get("text"));
      var1.styles = (ArrayList)var0.get("styles");
      var1.color = ChatColor.getByChar(var0.get("color").toString());
      var1.hoverActionName = (String)var0.get("hoverActionName");
      var1.hoverActionData = (JsonRepresentedObject)var0.get("hoverActionData");
      var1.clickActionName = (String)var0.get("clickActionName");
      var1.clickActionData = (String)var0.get("clickActionData");
      var1.insertionData = (String)var0.get("insertion");
      var1.translationReplacements = (ArrayList)var0.get("translationReplacements");
      return var1;
   }
}
