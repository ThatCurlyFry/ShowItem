package mkremins.fanciful.before1_8;

import java.util.HashMap;
import java.util.Map;
import mkremins.fanciful.before1_8.JsonRepresentedObject;
import org.bukkit.configuration.serialization.ConfigurationSerializable;
import org.bukkit.craftbukkit.libs.com.google.gson.stream.JsonWriter;

final class JsonString implements JsonRepresentedObject, ConfigurationSerializable {
   private String _value;

   public JsonString(CharSequence var1) {
      this._value = var1 == null?null:var1.toString();
   }

   public void writeJson(JsonWriter var1) {
      var1.value(this.getValue());
   }

   public String getValue() {
      return this._value;
   }

   public Map serialize() {
      HashMap var1 = new HashMap();
      var1.put("stringValue", this._value);
      return var1;
   }

   public static JsonString deserialize(Map var0) {
      return new JsonString(var0.get("stringValue").toString());
   }

   public String toString() {
      return this._value;
   }
}
