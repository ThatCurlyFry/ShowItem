package mkremins.fanciful.before1_8;

import com.google.common.base.Preconditions;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import mkremins.fanciful.before1_8.TextualComponent;
import mkremins.fanciful.before1_8.TextualComponent$ComplexTextTypeComponent$1;
import org.bukkit.configuration.serialization.ConfigurationSerializable;
import org.bukkit.craftbukkit.libs.com.google.gson.stream.JsonWriter;

final class TextualComponent$ComplexTextTypeComponent extends TextualComponent implements ConfigurationSerializable {
   private String _key;
   private Map _value;

   public TextualComponent$ComplexTextTypeComponent(String var1, Map var2) {
      this.setKey(var1);
      this.setValue(var2);
   }

   public String getKey() {
      return this._key;
   }

   public void setKey(String var1) {
      Preconditions.checkArgument(var1 != null && !var1.isEmpty(), "The key must be specified.");
      this._key = var1;
   }

   public Map getValue() {
      return this._value;
   }

   public void setValue(Map var1) {
      Preconditions.checkArgument(var1 != null, "The value must be specified.");
      this._value = var1;
   }

   public TextualComponent clone() {
      return new TextualComponent$ComplexTextTypeComponent(this.getKey(), this.getValue());
   }

   public void writeJson(JsonWriter var1) {
      var1.name(this.getKey());
      var1.beginObject();
      Iterator var3 = this._value.entrySet().iterator();

      while(var3.hasNext()) {
         Entry var2 = (Entry)var3.next();
         var1.name((String)var2.getKey()).value((String)var2.getValue());
      }

      var1.endObject();
   }

   public Map serialize() {
      return new TextualComponent$ComplexTextTypeComponent$1(this);
   }

   public static TextualComponent$ComplexTextTypeComponent deserialize(Map var0) {
      String var1 = null;
      HashMap var2 = new HashMap();
      Iterator var4 = var0.entrySet().iterator();

      while(var4.hasNext()) {
         Entry var3 = (Entry)var4.next();
         if(((String)var3.getKey()).equals("key")) {
            var1 = (String)var3.getValue();
         } else if(((String)var3.getKey()).startsWith("value.")) {
            var2.put(((String)var3.getKey()).substring(6), var3.getValue().toString());
         }
      }

      return new TextualComponent$ComplexTextTypeComponent(var1, var2);
   }

   public String getReadableString() {
      return this.getKey();
   }
}
