package me.icodetits.linkitem.plugins;

import java.util.Map;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

public abstract class Hook {
   public boolean isEnabled() {
      return this.getPlugin() != null && !this.getPlugin().isEmpty()?Bukkit.getPluginManager().isPluginEnabled(this.getPlugin()):false;
   }

   public abstract String getPlugin();

   public abstract Map getReplaceMap(Player var1, Player var2);
}
