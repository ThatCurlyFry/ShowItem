package me.icodetits.linkitem.plugins.hooks;

import com.google.common.collect.Maps;
import java.util.HashMap;
import java.util.Map;
import me.icodetits.linkitem.plugins.Hook;
import org.bukkit.entity.Player;

public class PlaceholdersHook extends Hook {
   public String getPlugin() {
      return "LinkItem";
   }

   public Map getReplaceMap(Player var1, Player var2) {
      if(var1 == null) {
         return null;
      } else {
         HashMap var3 = Maps.newHashMap();
         var3.put("{name}", var1.getName());
         var3.put("{dis_name}", var1.getDisplayName());
         return var3;
      }
   }
}
