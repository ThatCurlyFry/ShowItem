package net.amoebaman.util;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import org.apache.commons.lang.Validate;

public final class ArrayWrapper {
   private Object[] _array;

   @SafeVarargs
   public ArrayWrapper(Object... var1) {
      this.setArray(var1);
   }

   public Object[] getArray() {
      return this._array;
   }

   public void setArray(Object[] var1) {
      Validate.notNull(var1, "The array must not be null.");
      this._array = var1;
   }

   public boolean equals(Object var1) {
      return !(var1 instanceof ArrayWrapper)?false:Arrays.equals(this._array, ((ArrayWrapper)var1)._array);
   }

   public int hashCode() {
      return Arrays.hashCode(this._array);
   }

   public static Object[] toArray(Iterable var0, Class var1) {
      int var2 = -1;
      if(var0 instanceof Collection) {
         Collection var3 = (Collection)var0;
         var2 = var3.size();
      }

      if(var2 < 0) {
         var2 = 0;

         for(Iterator var4 = var0.iterator(); var4.hasNext(); ++var2) {
            Object var7 = (Object)var4.next();
         }
      }

      Object[] var8 = (Object[])Array.newInstance(var1, var2);
      int var9 = 0;

      Object var5;
      for(Iterator var6 = var0.iterator(); var6.hasNext(); var8[var9++] = var5) {
         var5 = (Object)var6.next();
      }

      return var8;
   }
}
