package net.amoebaman.util;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import net.amoebaman.util.ArrayWrapper;
import org.bukkit.Bukkit;

public final class Reflection {
   private static String _versionString;
   private static final Map _loadedNMSClasses = new HashMap();
   private static final Map _loadedOBCClasses = new HashMap();
   private static final Map _loadedFields = new HashMap();
   private static final Map _loadedMethods = new HashMap();

   public static synchronized String getVersion() {
      if(_versionString == null) {
         if(Bukkit.getServer() == null) {
            return null;
         }

         String var0 = Bukkit.getServer().getClass().getPackage().getName();
         _versionString = var0.substring(var0.lastIndexOf(46) + 1) + ".";
      }

      return _versionString;
   }

   public static synchronized Class getNMSClass(String var0) {
      if(_loadedNMSClasses.containsKey(var0)) {
         return (Class)_loadedNMSClasses.get(var0);
      } else {
         String var1 = "net.minecraft.server." + getVersion() + var0;
         Class var2 = null;

         try {
            var2 = Class.forName(var1);
         } catch (Exception var4) {
            var4.printStackTrace();
            _loadedNMSClasses.put(var0, (Object)null);
            return null;
         }

         _loadedNMSClasses.put(var0, var2);
         return var2;
      }
   }

   public static synchronized Class getOBCClass(String var0) {
      if(_loadedOBCClasses.containsKey(var0)) {
         return (Class)_loadedOBCClasses.get(var0);
      } else {
         String var1 = "org.bukkit.craftbukkit." + getVersion() + var0;
         Class var2 = null;

         try {
            var2 = Class.forName(var1);
         } catch (Exception var4) {
            var4.printStackTrace();
            _loadedOBCClasses.put(var0, (Object)null);
            return null;
         }

         _loadedOBCClasses.put(var0, var2);
         return var2;
      }
   }

   public static synchronized Object getHandle(Object var0) {
      Object var10000;
      try {
         var10000 = getMethod(var0.getClass(), "getHandle", new Class[0]).invoke(var0, new Object[0]);
      } catch (Exception var2) {
         var2.printStackTrace();
         return null;
      }

      return var10000;
   }

   public static synchronized Field getField(Class var0, String var1) {
      Object var2;
      if(!_loadedFields.containsKey(var0)) {
         var2 = new HashMap();
         _loadedFields.put(var0, var2);
      } else {
         var2 = (Map)_loadedFields.get(var0);
      }

      if(((Map)var2).containsKey(var1)) {
         return (Field)((Map)var2).get(var1);
      } else {
         Field var10000;
         try {
            Field var3 = var0.getDeclaredField(var1);
            var3.setAccessible(true);
            ((Map)var2).put(var1, var3);
            var10000 = var3;
         } catch (Exception var4) {
            var4.printStackTrace();
            ((Map)var2).put(var1, (Object)null);
            return null;
         }

         return var10000;
      }
   }

   public static synchronized Method getMethod(Class var0, String var1, Class... var2) {
      if(!_loadedMethods.containsKey(var0)) {
         _loadedMethods.put(var0, new HashMap());
      }

      Map var3 = (Map)_loadedMethods.get(var0);
      if(!var3.containsKey(var1)) {
         var3.put(var1, new HashMap());
      }

      Map var4 = (Map)var3.get(var1);
      ArrayWrapper var5 = new ArrayWrapper(var2);
      if(var4.containsKey(var5)) {
         return (Method)var4.get(var5);
      } else {
         Method[] var9;
         int var8 = (var9 = var0.getMethods()).length;

         for(int var7 = 0; var7 < var8; ++var7) {
            Method var6 = var9[var7];
            if(var6.getName().equals(var1) && Arrays.equals(var2, var6.getParameterTypes())) {
               var6.setAccessible(true);
               var4.put(var5, var6);
               return var6;
            }
         }

         var4.put(var5, (Object)null);
         return null;
      }
   }
}
